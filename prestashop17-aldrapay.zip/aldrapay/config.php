<?php
$aldrapayurl = "https://secure.aldrapay.com";
$apiurl = $aldrapayurl;
$api_initialRequestUri = '/transaction/execute';
$api_redirectCustomerUri = '/transaction/customer';
$sslport = 443;
$verifypeer = 1;
$verifyhost = 2;
?>